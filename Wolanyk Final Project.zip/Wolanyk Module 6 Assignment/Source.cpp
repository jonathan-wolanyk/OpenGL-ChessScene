// Jonathan Wolanyk
// Dr. Alnaji
// CS-330
// 2/19/2023

// Wolanyk Final Project

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"

#include <iostream>

#include "cylinder.h"
#include "ShapeData.h"
#include "ShapeGenerator.h"
#include "Vertex.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

// Setup
#pragma region
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
unsigned int loadTexture(const char* path);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

// camera
Camera camera(glm::vec3(-1.0f, 4.5f, 15.0f));
glm::vec3 cameraPos = glm::vec3(0.0f, 1.5f, 15.0);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
glm::vec3 cameraDown = glm::vec3(0.0f, -1.0f, 0.0f);
// cameraSpeed moved to global variable since we will be modifying it in UMouseScrollCallback
float cameraSpeed = 2.5f;

// Orthographics vs 3D bools
bool mouseInput = true;
bool orthographic = false;

// Mouse variables (sensitivity and mouse-driven camera movement)
bool firstMouse = true;
float yaw = -90.0f;
float pitch = 0.0f;
float lastX = SCR_WIDTH / 2.0;
float lastY = SCR_HEIGHT / 2.0;
float fov = 45.0f;

// timing
float deltaTime = 0.0f;
float lastFrame = 0.0f;

// Objects

// Pawn Structure
unsigned int VBO, VAO;
unsigned int VBO2, VAO2;
unsigned int VBO3, VAO3;
unsigned int VBO4, VAO4;
unsigned int VBO5, VAO5;

GLsizeiptr currentOffset = 0;
ShapeData sphere = ShapeGenerator::makeSphere();
unsigned int sphereVBO{}, sphereVAO;
// sphere 1
GLuint sphereNumIndices;
GLuint sphereVertexArrayObjectID;
GLuint sphereIndexByteOffset;
// sphere 2
GLuint sphereNumIndices2;
GLuint sphereVertexArrayObjectID2;
GLuint sphereIndexByteOffset2;
// plane
struct GLMesh {
	GLuint planeVAO;
	GLuint planeVBO;
	GLuint planeVerts;
};
// plane mesh data
GLMesh planeMesh;
// Triangle mesh data
GLMesh gMesh;
// Texture
GLuint gTextureId;
glm::vec2 gUVScale(5.0f, 5.0f);
GLint gTexWrapMode = GL_REPEAT;
// offset variables for plane, sphere
const uint NUM_VERTICES_PER_TRI = 3;
const uint NUM_FLOATS_PER_VERTICE = 9;
const uint VERTEX_BYTE_SIZE = NUM_FLOATS_PER_VERTICE * sizeof(float);

// lighting
glm::vec3 lightPos(1.2f, 1.0f, 2.0f);
#pragma endregion

int main()
{
	// glfw: initialize and configure
	// ------------------------------
#pragma region
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Wolanyk Final Project", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);

	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);
#pragma endregion

	// build and compile our shader zprogram
	// ------------------------------------
	Shader ourShader("shaderfiles/7.3.camera.vs", "shaderfiles/7.3.camera.fs");
	Shader lightingShader("shaderfiles/6.multiple_lights.vs", "shaderfiles/6.multiple_lights.fs");
	
	// Create Mesh
#pragma region
	// set up vertex data (and buffer(s)) and configure vertex attributes
	// ------------------------------------------------------------------
	const float REPEAT = 1;
	float vertices[] = {
		// positions				// texture coords
		-15.0f,  -3.22f, 15.0f,		0.0f, 0.0f, // front left
		15.0f,  -3.22f, -15.0f,		REPEAT, REPEAT, // back right
		15.0f,  -3.22f,  15.0f,		REPEAT, 0.0f, // front right

		-15.0f,  -3.22f,  15.0f,	0.0f, 0.0f, // front left
		15.0f,  -3.22f, -15.0f,		REPEAT, REPEAT, // back right
		-15.0f,  -3.22f, -15.0f,	0.0f, REPEAT, // back left
	};

	float lightVertices[] = {
		// positions			// normals           // texture coords
		// Back
		-1.0f, -1.0f, -1.0f,	0.0f,  0.0f,		-1.0f,  0.0f,  0.0f,
		 1.0f, -1.0f, -1.0f,	0.0f,  0.0f,		-1.0f,  1.0f,  0.0f,
		 1.0f,  1.0f, -1.0f,	0.0f,  0.0f,		-1.0f,  1.0f,  1.0f,
		 1.0f,  1.0f, -1.0f,	0.0f,  0.0f,		-1.0f,  1.0f,  1.0f,
		-1.0f,  1.0f, -1.0f,	0.0f,  0.0f,		-1.0f,  0.0f,  1.0f,
		-1.0f, -1.0f, -1.0f,	0.0f,  0.0f,		-1.0f,  0.0f,  0.0f,

		// Front
		-1.0f, -1.0f,  1.0f,	0.0f,  0.0f,		 1.0f,  0.0f,  0.0f,
		 1.0f, -1.0f,  1.0f,	0.0f,  0.0f,		 1.0f,  1.0f,  0.0f,
		 1.0f,  1.0f,  1.0f,	0.0f,  0.0f,		 1.0f,  1.0f,  1.0f,
		 1.0f,  1.0f,  1.0f,	0.0f,  0.0f,		 1.0f,  1.0f,  1.0f,
		-1.0f,  1.0f,  1.0f,	0.0f,  0.0f,		 1.0f,  0.0f,  1.0f,
		-1.0f, -1.0f,  1.0f,	0.0f,  0.0f,		 1.0f,  0.0f,  0.0f,

		// Left
		-1.0f,  1.0f,  1.0f,	1.0f,  0.0f,		 0.0f,  1.0f,  0.0f,
		-1.0f,  1.0f, -1.0f,	-1.0f,  0.0f,		 0.0f,  1.0f,  1.0f,
		-1.0f, -1.0f, -1.0f,	-1.0f,  0.0f,		 0.0f,  0.0f,  1.0f,
		-1.0f, -1.0f, -1.0f,	-1.0f,  0.0f,		 0.0f,  0.0f,  1.0f,
		-1.0f, -1.0f,  1.0f,	-1.0f,  0.0f,		 0.0f,  0.0f,  0.0f,
		-1.0f,  1.0f,  1.0f,	-1.0f,  0.0f,		 0.0f,  1.0f,  0.0f,

		// Right
		 1.0f,  1.0f,  1.0f,	1.0f,  0.0f,		0.0f,  1.0f,  0.0f,
		 1.0f,  1.0f, -1.0f,	1.0f,  0.0f,		0.0f,  1.0f,  1.0f,
		 1.0f, -1.0f, -1.0f,	1.0f,  0.0f,		0.0f,  0.0f,  1.0f,
		 1.0f, -1.0f, -1.0f,	1.0f,  0.0f,		0.0f,  0.0f,  1.0f,
		 1.0f, -1.0f,  1.0f,	1.0f,  0.0f,		0.0f,  0.0f,  0.0f,
		 1.0f,  1.0f,  1.0f,	1.0f,  0.0f,		0.0f,  1.0f,  0.0f,

		 // Bottom
		-1.0f, -1.0f, -1.0f,	0.0f, -1.0f,		0.0f,  0.0f,  1.0f,
		 1.0f, -1.0f, -1.0f,	0.0f, -1.0f,		0.0f,  1.0f,  1.0f,
		 1.0f, -1.0f,  1.0f,	0.0f, -1.0f,		0.0f,  1.0f,  0.0f,
		 1.0f, -1.0f,  1.0f,	0.0f, -1.0f,		0.0f,  1.0f,  0.0f,
		-1.0f, -1.0f,  1.0f,	0.0f, -1.0f,		0.0f,  0.0f,  0.0f,
		-1.0f, -1.0f, -1.0f,	0.0f, -1.0f,		0.0f,  0.0f,  1.0f,

		// Top
		-1.0f,  1.0f, -1.0f,	0.0f,  1.0f,		0.0f,  0.0f,  1.0f,
		 1.0f,  1.0f, -1.0f,	0.0f,  1.0f,		0.0f,  1.0f,  1.0f,
		 1.0f,  1.0f,  1.0f,	0.0f,  1.0f,		0.0f,  1.0f,  0.0f,
		 1.0f,  1.0f,  1.0f,	0.0f,  1.0f,		0.0f,  1.0f,  0.0f,
		-1.0f,  1.0f,  1.0f,	0.0f,  1.0f,		0.0f,  0.0f,  0.0f,
		-1.0f,  1.0f, -1.0f,	0.0f,  1.0f,		0.0f,  0.0f,  1.0f
	};

	// positions of the point lights
	glm::vec3 pointLightPositions[] = {
		glm::vec3(-8.0f,  7.5f,  1.0f),
		glm::vec3(5.0f, 9.5f, 0.25f),
	};
	// first, configure the pyramid's VAO (and VBO)
	unsigned int VBO, pyramidVAO;
	glGenVertexArrays(1, &pyramidVAO);
	glGenBuffers(1, &VBO);

	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	glBindVertexArray(pyramidVAO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
	glEnableVertexAttribArray(2);

	// configure the light's VAO
	unsigned int lightVBO, lightCubeVAO;
	glGenVertexArrays(1, &lightCubeVAO);
	glGenBuffers(1, &lightVBO);

	glBindBuffer(GL_ARRAY_BUFFER, lightVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(lightVertices), lightVertices, GL_STATIC_DRAW);

	glBindVertexArray(lightCubeVAO);
	glBindBuffer(GL_ARRAY_BUFFER, lightVBO);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);

	// plane
#pragma region
	const GLuint floatsPerVertex = 3;
	const GLuint floatsPerUV = 2;
	planeMesh.planeVerts = sizeof(vertices) / (sizeof(vertices[0]) * (floatsPerVertex + floatsPerUV));

	glGenVertexArrays(1, &planeMesh.planeVAO); // we can also generate multiple VAOs or buffers at the same time
	glBindVertexArray(planeMesh.planeVAO);

	// Creates plane
	glGenBuffers(1, &planeMesh.planeVBO);
	glBindBuffer(GL_ARRAY_BUFFER, planeMesh.planeVBO); // Activates the buffer
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU
	GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);
	glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
	glEnableVertexAttribArray(2);
#pragma endregion

	// Pawn Structure
#pragma region
	// Creates base cylinder
	glGenVertexArrays(1, &VAO2);
	glGenBuffers(1, &VBO2);
	glBindVertexArray(VAO2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO2);

	// Creates the second cylinder
	glGenVertexArrays(1, &VAO3);
	glGenBuffers(1, &VBO3);
	glBindVertexArray(VAO3);
	glBindBuffer(GL_ARRAY_BUFFER, VBO3);

	// Creates the third cylinder
	glGenVertexArrays(1, &VAO4);
	glGenBuffers(1, &VBO4);
	glBindVertexArray(VAO4);
	glBindBuffer(GL_ARRAY_BUFFER, VBO4);

	// Creates the third cylinder
	glGenVertexArrays(1, &VAO5);
	glGenBuffers(1, &VBO5);
	glBindVertexArray(VAO5);
	glBindBuffer(GL_ARRAY_BUFFER, VBO5);

	// Creates sphere
	glGenVertexArrays(1, &sphereVAO);
	glGenBuffers(1, &sphereVBO);
	glBindVertexArray(sphereVAO);
	glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
	glBufferData(GL_ARRAY_BUFFER, sphere.vertexBufferSize() + sphere.indexBufferSize(), 0, GL_STATIC_DRAW);
	currentOffset = 0;
	glBufferSubData(GL_ARRAY_BUFFER, currentOffset, sphere.vertexBufferSize(), sphere.vertices);
	currentOffset += sphere.vertexBufferSize();
	sphereIndexByteOffset = currentOffset;
	glBufferSubData(GL_ARRAY_BUFFER, currentOffset, sphere.indexBufferSize(), sphere.indices);
	sphereNumIndices = sphere.numIndices;
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, VERTEX_BYTE_SIZE, (void*)0);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, VERTEX_BYTE_SIZE, (void*)(sizeof(float) * 3));
	glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, VERTEX_BYTE_SIZE, (void*)(sizeof(float) * 6));
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, sphereVBO);

#pragma endregion

	// load textures (we now use a utility function to keep the code more organized)
	// -----------------------------------------------------------------------------
	unsigned int diffuseMap = loadTexture("images/lightWood.png");
	unsigned int specularMap = loadTexture("images/lightWood.png");
	unsigned int lightWoodTexture = loadTexture("images/lightWood.png");
	unsigned int chessboardTexture = loadTexture("images/chessboard.png");
	unsigned int woodTexture = loadTexture("images/HiResWood.png");


	// shader configuration
	// --------------------
	lightingShader.use();
	lightingShader.setInt("material.diffuse", 1);
	lightingShader.setInt("material.specular", 2);


	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// pass projection matrix to shader (note that in this case it could change every frame)
		glm::mat4 projection;
		lightingShader.setMat4("projection", projection);

		// Orthographic or Perspective views
		if (!orthographic) {
			// Creates a perspective projection
			projection = glm::perspective(45.0f, (GLfloat)SCR_WIDTH / (GLfloat)SCR_HEIGHT, 0.1f, 100.0f);
		}
		else if (orthographic) {
			// Orthographic view settings
			float scale = 100.0f;
			projection = glm::ortho(-((float)SCR_WIDTH / scale), (float)SCR_WIDTH / scale, -(float)SCR_HEIGHT / scale, ((float)SCR_HEIGHT / scale), 0.1f, 100.0f);
		}

		// render
		// ------
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glm::vec3 pointLightColors[] = {
			glm::vec3(0.98f, 0.93f, 0.65f),
			glm::vec3(0.98f, 0.93f, 0.65f),
		};

		

		// Light settings
#pragma region
		// be sure to activate shader when setting uniforms/drawing objects
		lightingShader.use();
		lightingShader.setVec3("viewPos", camera.Position);
		lightingShader.setFloat("material.shininess", 32.0f);

		// directional light
		lightingShader.setVec3("dirLight.direction", 0.1f, 0.1f, 0.1f);
		lightingShader.setVec3("dirLight.ambient", 0.5f, 0.5f, 0.5f);
		lightingShader.setVec3("dirLight.diffuse", pointLightColors[0].x * 2, pointLightColors[0].y * 2, pointLightColors[0].z * 2);
		lightingShader.setVec3("dirLight.specular", 1, 1, 1);

		// light 1
		lightingShader.setVec3("pointLights[0].position", pointLightPositions[0].x, pointLightPositions[0].y, pointLightPositions[0].z);
		lightingShader.setVec3("pointLights[0].ambient", 15, 15, 15);
		lightingShader.setVec3("pointLights[0].diffuse", pointLightColors[0].x * 5.0f, pointLightColors[0].y * 2.0f, pointLightColors[0].z * 5.0f);
		lightingShader.setVec3("pointLights[0].specular", pointLightColors[0].x, pointLightColors[0].y, pointLightColors[0].z);
		lightingShader.setFloat("pointLights[0].constant", 1.0f);
		lightingShader.setFloat("pointLights[0].linear", 0.7f);
		lightingShader.setFloat("pointLights[0].quadratic", 1.8f);

		// light 2
		lightingShader.setVec3("pointLights[1].position", pointLightPositions[1].x, pointLightPositions[1].y, pointLightPositions[1].z);
		lightingShader.setVec3("pointLights[1].ambient", 126, 119, 83);
		lightingShader.setVec3("pointLights[1].diffuse", pointLightColors[1].x * 5.0f, pointLightColors[1].y * 2.0f, pointLightColors[1].z * 5.0f);
		lightingShader.setVec3("pointLights[0].specular", pointLightColors[1].x, pointLightColors[0].y, pointLightColors[0].z);
		lightingShader.setFloat("pointLights[1].constant", 1.0f);
		lightingShader.setFloat("pointLights[1].linear", 0.7f);
		lightingShader.setFloat("pointLights[1].quadratic", 1.8f);


		glm::mat4 view = camera.GetViewMatrix();
		lightingShader.setMat4("projection", projection);
		lightingShader.setMat4("view", view);

		// world transformation
		glm::mat4 model = glm::mat4(1.0f);
		lightingShader.setMat4("model", model);

		// bind diffuse map
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, lightWoodTexture);
		// bind specular map
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, lightWoodTexture);
#pragma endregion

		// Draw objects
#pragma region
		// Pawn 1
		float pawnX = 1.75f;
		float pawnZ = -2.0f;
		// Draw first cylinder
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, woodTexture);
		// bind specular map
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, woodTexture);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawnX, -0.15f, pawnZ));
		model = glm::scale(model, glm::vec3(0.75f, 0.75f, 0.75f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C(2, 10, 1, true, true, true);
		C.render();

		// draw second cylinder (the neck of the pawn)
		glBindVertexArray(VAO3);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawnX, 1.0f, pawnZ));
		model = glm::scale(model, glm::vec3(0.35f, 2.75f, 0.35f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C2(2, 10, 1, true, true, true);
		C2.render();

		// draw third cylinder (ring beneath pawn's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawnX, 2.25f, pawnZ));
		model = glm::scale(model, glm::vec3(0.6f, 0.15f, 0.6f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C3(2, 10, 1, true, true, true);
		C3.render();

		// draw fourth cylinder (ring at bottom of pawn's neck)
		glBindVertexArray(VAO5);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawnX, 0.35f, pawnZ));
		model = glm::scale(model, glm::vec3(0.6f, 0.25f, 0.6f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C4(2, 10, 1, true, true, true);
		C4.render();

		// draw sphere
		glBindVertexArray(sphereVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(pawnX, 3.25f, pawnZ));
		model = glm::scale(model, glm::vec3(1.2f));
		lightingShader.setMat4("model", model);
		glDrawElements(GL_TRIANGLES, sphereNumIndices, GL_UNSIGNED_SHORT, (void*)sphereIndexByteOffset);

		// Pawn 2 settings
		float pawn2X = -5.5f;
		float pawn2Z = 2.0f;
		// bind diffuse map
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, lightWoodTexture);
		// bind specular map
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, lightWoodTexture);

		// Draw first cylinder
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawn2X, -0.15f, pawn2Z));
		model = glm::scale(model, glm::vec3(0.75f, 0.75f, 0.75f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C6(2, 10, 1, true, true, true);
		C6.render();

		// draw second cylinder (the neck of the pawn)
		glBindVertexArray(VAO3);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawn2X, 1.0f, pawn2Z));
		model = glm::scale(model, glm::vec3(0.35f, 2.75f, 0.35f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C7(2, 10, 1, true, true, true);
		C7.render();

		// draw third cylinder (ring beneath pawn's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawn2X, 2.25f, pawn2Z));
		model = glm::scale(model, glm::vec3(0.6f, 0.15f, 0.6f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C8(2, 10, 1, true, true, true);
		C8.render();

		// draw fourth cylinder (ring at bottom of pawn's neck)
		glBindVertexArray(VAO5);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(pawn2X, 0.35f, pawn2Z));
		model = glm::scale(model, glm::vec3(0.6f, 0.25f, 0.6f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C9(2, 10, 1, true, true, true);
		C9.render();

		// draw sphere
		glBindVertexArray(sphereVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(pawn2X, 3.25f, pawn2Z));
		model = glm::scale(model, glm::vec3(1.2f));
		lightingShader.setMat4("model", model);
		glDrawElements(GL_TRIANGLES, sphereNumIndices, GL_UNSIGNED_SHORT, (void*)sphereIndexByteOffset);

		// Bishop settings
		float bishopX = -1.75f;
		float bishopZ = -5.75f;
		// bind diffuse map
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, lightWoodTexture);
		// bind specular map
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, lightWoodTexture);

		// Draw first cylinder
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, lightWoodTexture);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(bishopX, 0.0f, bishopZ));
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C10(2, 10, 1, true, true, true);
		C10.render();

		// draw second cylinder (the neck of the bishop)
		glBindVertexArray(VAO3);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(bishopX, 1.75f, bishopZ));
		model = glm::scale(model, glm::vec3(0.45f, 4.5f, 0.45f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C11(2, 10, 1, true, true, true);
		C11.render();

		// draw third cylinder (ring beneath bishop's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(bishopX, 2.95f, bishopZ));
		model = glm::scale(model, glm::vec3(0.75f, 0.3f, 0.75f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C12(2, 10, 1, true, true, true);
		C12.render();

		// draw cylinder (accent ring 1 beneath bishop's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(bishopX, 3.15f, bishopZ));
		model = glm::scale(model, glm::vec3(0.65f, 0.2f, 0.65f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CB1(2, 10, 1, true, true, true);
		CB1.render();

		// draw cylinder (accent ring 2 beneath bishop's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(bishopX, 2.75f, bishopZ));
		model = glm::scale(model, glm::vec3(0.65f, 0.2f, 0.65f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CB2(2, 10, 1, true, true, true);
		CB2.render();

		// draw fourth cylinder (ring at bottom of bishop's neck)
		glBindVertexArray(VAO5);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(bishopX, 0.65f, bishopZ));
		model = glm::scale(model, glm::vec3(0.75f, 0.25f, 0.75f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C13(2, 10, 1, true, true, true);
		C13.render();

		// draw fifth cylinder (smaller ring at bottom of bishop's neck)
		glBindVertexArray(VAO5);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(bishopX, 4.0f, bishopZ));
		model = glm::scale(model, glm::vec3(0.5f, 0.15f, 0.5f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder C14(2, 10, 1, true, true, true);
		C14.render();

		// draw sphere 1
		glBindVertexArray(sphereVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(bishopX, 4.4f, bishopZ));
		model = glm::scale(model, glm::vec3(1.45f));
		lightingShader.setMat4("model", model);
		glDrawElements(GL_TRIANGLES, sphereNumIndices, GL_UNSIGNED_SHORT, (void*)sphereIndexByteOffset);

		// draw sphere 2
		glBindVertexArray(sphereVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(bishopX, 5.95f, bishopZ));
		model = glm::scale(model, glm::vec3(0.4f));
		lightingShader.setMat4("model", model);
		glDrawElements(GL_TRIANGLES, sphereNumIndices, GL_UNSIGNED_SHORT, (void*)sphereIndexByteOffset);


		// Queen settings
		float queenX = 5.65f;
		float queenZ = 1.9f;
		// bind diffuse map
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, woodTexture);
		// bind specular map
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, woodTexture);

		// Draw first cylinder
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, woodTexture);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 0.0f, queenZ));
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ1(2, 10, 1, true, true, true);
		CQ1.render();

		// draw second cylinder (the neck of the queen)
		glBindVertexArray(VAO3);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 1.65f, queenZ));
		model = glm::scale(model, glm::vec3(0.35f, 4.2f, 0.35f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ2(2, 10, 1, true, true, true);
		CQ2.render();

		// draw third cylinder (ring beneath queen's mid)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 2.25f, queenZ));
		model = glm::scale(model, glm::vec3(0.75f, 0.3f, 0.75f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ3(2, 10, 1, true, true, true);
		CQ3.render();

		// draw cylinder (accent ring 1 beneath queen's mid)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 2.45f, queenZ));
		model = glm::scale(model, glm::vec3(0.65f, 0.2f, 0.65f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQA1(2, 10, 1, true, true, true);
		CQA1.render();

		// draw cylinder (accent ring 2 beneath queen's mid)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 2.05f, queenZ));
		model = glm::scale(model, glm::vec3(0.65f, 0.2f, 0.65f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQA2(2, 10, 1, true, true, true);
		CQA2.render();

		// draw fourth cylinder (ring at bottom of queen's neck)
		glBindVertexArray(VAO5);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 0.55f, queenZ));
		model = glm::scale(model, glm::vec3(0.75f, 0.25f, 0.75f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ4(2, 10, 1, true, true, true);
		CQ4.render();

		// draw fifth cylinder (smaller ring at bottom of queens's neck)
		glBindVertexArray(VAO5);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 3.35f, queenZ));
		model = glm::scale(model, glm::vec3(0.5f, 0.15f, 0.5f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ5(2, 10, 1, true, true, true);
		CQ5.render();

		// draw  cylinder (thicker neck beneath queen's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 2.8f, queenZ));
		model = glm::scale(model, glm::vec3(0.45f, 1.5f, 0.45f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ6(2, 10, 1, true, true, true);
		CQ6.render();

		// draw sphere 1
		glBindVertexArray(sphereVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(queenX, 4.75f, queenZ));
		model = glm::scale(model, glm::vec3(1.25f));
		lightingShader.setMat4("model", model);
		glDrawElements(GL_TRIANGLES, sphereNumIndices, GL_UNSIGNED_SHORT, (void*)sphereIndexByteOffset);

		// draw sphere 2
		glBindVertexArray(sphereVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(queenX, 6.05f, queenZ));
		model = glm::scale(model, glm::vec3(0.25f));
		lightingShader.setMat4("model", model);
		glDrawElements(GL_TRIANGLES, sphereNumIndices, GL_UNSIGNED_SHORT, (void*)sphereIndexByteOffset);

		// draw  cylinder (ring beneath queen's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 3.55f, queenZ));
		model = glm::scale(model, glm::vec3(0.9f, 0.4f, 0.9f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ7(2, 10, 1, true, true, true);
		CQ7.render();

		// draw  cylinder (ring beneath queen's head)
		glBindVertexArray(VAO4);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(queenX, 3.75f, queenZ));
		model = glm::scale(model, glm::vec3(0.75f, 0.3f, 0.75f));
		lightingShader.setMat4("model", model);
		static_meshes_3D::Cylinder CQ8(2, 10, 1, true, true, true);
		CQ8.render();

		// Plane 
		// bind diffuse map
		// bind diffuse map
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, chessboardTexture);
		// bind specular map
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, chessboardTexture);


		// draw plane
		glEnableVertexAttribArray(planeMesh.planeVerts);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, chessboardTexture);
		glBindVertexArray(planeMesh.planeVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(0.0f, 2.7f, 0.0f));
		lightingShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, planeMesh.planeVerts);

		// also draw the lamp object(s)
		ourShader.use();
		ourShader.setMat4("projection", projection);
		ourShader.setMat4("view", view);

		// draw light 1
		glBindVertexArray(lightCubeVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, pointLightPositions[0]);
		model = glm::scale(model, glm::vec3(0.25f));
		ourShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, 36);

		// draw light 2
		glBindVertexArray(lightCubeVAO);
		model = glm::mat4(1.0f);
		model = glm::translate(model, pointLightPositions[1]);
		model = glm::scale(model, glm::vec3(0.25f));
		ourShader.setMat4("model", model);
		glDrawArrays(GL_TRIANGLES, 0, 36);
#pragma endregion

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// optional: de-allocate all resources once they've outlived their purpose:
	// ------------------------------------------------------------------------
	glDeleteVertexArrays(1, &pyramidVAO);
	glDeleteVertexArrays(1, &lightCubeVAO);
	glDeleteBuffers(1, &VBO);

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float cameraOffset = camera.MovementSpeed * deltaTime;

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);

	// Q and E to go up and down
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		camera.Position += cameraOffset * cameraUp;
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		camera.Position += cameraOffset * cameraDown;

	// P to toggle orthographic
	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {

		// toggle orthographic bool
		orthographic = !orthographic;
		if (orthographic) {
			std::cout << "Now in orthographic view" << std::endl;
		}
		else {
			std::cout << "Now in perspective view" << std::endl;
		}

		// ensures key press only registers once
		glfwWaitEventsTimeout(1.0f);
	}
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	// If speed is above minimum, increase or decrease
	if (camera.MovementSpeed > 1.0f) {
		std::cout << "Adding " << yoffset << " to camera speed" << std::endl;
		camera.MovementSpeed += yoffset;
	}

	// If speed is at minimum and user scrolls up, increase speed
	else if (camera.MovementSpeed <= 1.0f && yoffset > 0) {
		camera.MovementSpeed += yoffset;
	}

	// If user is at minimum and tries to decrease speed, do not allow and notify user
	else {
		std::cout << "Camera speed cannot be decreased any more" << std::endl;
	}
}

// utility function for loading a 2D texture from file
// ---------------------------------------------------
unsigned int loadTexture(char const* path)
{
	unsigned int textureID;
	glGenTextures(1, &textureID);

	int width, height, nrComponents;
	unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
	if (data)
	{
		GLenum format;
		if (nrComponents == 1)
			format = GL_RED;
		else if (nrComponents == 3)
			format = GL_RGB;
		else if (nrComponents == 4)
			format = GL_RGBA;

		glBindTexture(GL_TEXTURE_2D, textureID);
		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		stbi_image_free(data);
	}
	else
	{
		std::cout << "Texture failed to load at path: " << path << std::endl;
		stbi_image_free(data);
	}

	return textureID;
}